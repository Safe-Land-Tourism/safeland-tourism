// Safe Land Tourism LLC — Admin Panel
// Loads data.json (or a locally-saved draft), lets you edit it in a form,
// and lets you download the updated JSON to re-upload to GitHub.

const DRAFT_KEY = 'safeland_admin_draft_v1';
let state = null;

function getPath(obj, path){
  return path.split('.').reduce((o,k) => (o == null ? o : o[k]), obj);
}
function setPath(obj, path, value){
  const keys = path.split('.');
  let cur = obj;
  for(let i=0;i<keys.length-1;i++){
    cur = cur[keys[i]];
  }
  cur[keys[keys.length-1]] = value;
}

function saveDraft(){
  localStorage.setItem(DRAFT_KEY, JSON.stringify(state));
  const ind = document.getElementById('save-indicator');
  ind.textContent = 'Draft saved ✓ ' + new Date().toLocaleTimeString();
}

async function init(){
  const draft = localStorage.getItem(DRAFT_KEY);
  if(draft){
    state = JSON.parse(draft);
  } else {
    const res = await fetch('data.json?_=' + Date.now());
    state = await res.json();
  }
  buildTabs();
  renderPanel('hero');
  wireGlobalActions();
}

/* ---------------- Tabs ---------------- */
const TABS = [
  { id: 'hero', label: 'Site & Hero' },
  { id: 'about', label: 'About' },
  { id: 'services', label: 'Services' },
  { id: 'destinations', label: 'Destinations' },
  { id: 'testimonials', label: 'Testimonials' },
  { id: 'contact', label: 'Contact & Footer' },
];

function buildTabs(){
  const tabsEl = document.getElementById('admin-tabs');
  tabsEl.innerHTML = TABS.map(t => `<button data-tab="${t.id}">${t.label}</button>`).join('');
  tabsEl.addEventListener('click', e => {
    const btn = e.target.closest('button[data-tab]');
    if(!btn) return;
    renderPanel(btn.dataset.tab);
  });
}

function setActiveTab(id){
  document.querySelectorAll('#admin-tabs button').forEach(b => {
    b.classList.toggle('active', b.dataset.tab === id);
  });
}

/* ---------------- Field helpers ---------------- */
function field(label, path, value, type='input'){
  const val = (value ?? '').toString().replace(/"/g,'&quot;');
  if(type === 'textarea'){
    return `<div class="a-field"><label>${label}</label><textarea data-path="${path}">${value ?? ''}</textarea></div>`;
  }
  return `<div class="a-field"><label>${label}</label><input data-path="${path}" value="${val}"></div>`;
}

/* ---------------- Panels ---------------- */
function renderPanel(tabId){
  setActiveTab(tabId);
  const content = document.getElementById('admin-content');
  let html = '';

  if(tabId === 'hero'){
    html = `
      <div class="a-card"><h3>Site</h3>
        ${field('Site title (browser tab)', 'site.title', state.site.title)}
        ${field('Tagline', 'site.tagline', state.site.tagline)}
        ${field('Logo text (header)', 'site.logo_text', state.site.logo_text)}
      </div>
      <div class="a-card"><h3>Hero section</h3>
        ${field('Eyebrow (small tag above title)', 'hero.eyebrow', state.hero.eyebrow)}
        ${field('Main heading', 'hero.name', state.hero.name)}
        ${field('Role / subheading', 'hero.role', state.hero.role)}
        ${field('Intro paragraph', 'hero.intro', state.hero.intro, 'textarea')}
        <div class="a-row2">
          ${field('Primary button text', 'hero.cta_text', state.hero.cta_text)}
          ${field('Primary button link', 'hero.cta_link', state.hero.cta_link)}
        </div>
        <div class="a-row2">
          ${field('Secondary button text', 'hero.secondary_cta_text', state.hero.secondary_cta_text)}
          ${field('Secondary button link', 'hero.secondary_cta_link', state.hero.secondary_cta_link)}
        </div>
      </div>`;
  }

  if(tabId === 'about'){
    html = `
      <div class="a-card"><h3>About section</h3>
        ${field('Heading', 'about.heading', state.about.heading)}
        ${field('Paragraph', 'about.text', state.about.text, 'textarea')}
        <div class="a-row2">
          ${field('Director / owner name', 'about.md_name', state.about.md_name)}
          ${field('Director / owner title', 'about.md_title', state.about.md_title)}
        </div>
      </div>
      <div class="a-card"><h3>Stats (3 short numbers)</h3>
        <div id="stats-list"></div>
      </div>`;
  }

  if(tabId === 'services'){
    html = `<div class="a-card"><h3>Services list</h3><div id="services-list"></div>
      <button class="a-btn a-btn-add a-add-row" data-action="add-services">+ Add service</button></div>`;
  }

  if(tabId === 'destinations'){
    html = `<div class="a-card"><h3>Destinations / gallery</h3><div id="destinations-list"></div>
      <button class="a-btn a-btn-add a-add-row" data-action="add-destinations">+ Add destination</button></div>`;
  }

  if(tabId === 'testimonials'){
    html = `<div class="a-card"><h3>Testimonials</h3><div id="testimonials-list"></div>
      <button class="a-btn a-btn-add a-add-row" data-action="add-testimonials">+ Add testimonial</button></div>`;
  }

  if(tabId === 'contact'){
    const s = state.contact.socials || {};
    html = `
      <div class="a-card"><h3>Contact section</h3>
        ${field('Heading', 'contact.heading', state.contact.heading)}
        ${field('Subtext', 'contact.subtext', state.contact.subtext)}
        ${field('Address', 'contact.address', state.contact.address)}
        <div class="a-row2">
          ${field('Phone', 'contact.phone', state.contact.phone)}
          ${field('Email', 'contact.email', state.contact.email)}
        </div>
        ${field('Website', 'contact.website', state.contact.website)}
      </div>
      <div class="a-card"><h3>Social links (leave blank to hide)</h3>
        <div class="a-row3">
          ${field('Instagram URL', 'contact.socials.instagram', s.instagram)}
          ${field('Facebook URL', 'contact.socials.facebook', s.facebook)}
          ${field('YouTube URL', 'contact.socials.youtube', s.youtube)}
        </div>
        <div class="a-row3">
          ${field('LinkedIn URL', 'contact.socials.linkedin', s.linkedin)}
          ${field('Twitter/X URL', 'contact.socials.twitter', s.twitter)}
          ${field('TikTok URL', 'contact.socials.tiktok', s.tiktok)}
        </div>
      </div>
      <div class="a-card"><h3>Footer</h3>
        ${field('Footer text', 'footer.text', state.footer.text)}
      </div>`;
  }

  content.innerHTML = html;

  if(tabId === 'about') renderStats();
  if(tabId === 'services') renderRepeatable('services', ['icon','title'], ['Icon (emoji)','Title']);
  if(tabId === 'destinations') renderRepeatable('destinations', ['name','image'], ['Name','Image URL (optional)']);
  if(tabId === 'testimonials') renderRepeatable('testimonials', ['name','role','text'], ['Name','Role / trip','Quote'], ['input','input','textarea']);
}

/* ---------------- Repeatable list renderer ---------------- */
function renderRepeatable(key, keys, labels, types){
  const listEl = document.getElementById(key + '-list');
  const items = state[key] || [];
  listEl.innerHTML = items.map((item, i) => `
    <div class="a-repeat-item">
      <button class="a-btn a-btn-danger a-remove" data-action="remove-${key}" data-index="${i}">Remove</button>
      ${keys.map((k,ki) => field(labels[ki], `${key}.${i}.${k}`, item[k], types && types[ki] === 'textarea' ? 'textarea' : 'input')).join('')}
    </div>`).join('') || '<p style="color:var(--ink-soft);font-size:14px;">No items yet — add one below.</p>';
}

function renderStats(){
  const listEl = document.getElementById('stats-list');
  const items = state.about.stats || [];
  listEl.innerHTML = items.map((item,i) => `
    <div class="a-row2" style="margin-bottom:10px;">
      ${field('Number', `about.stats.${i}.number`, item.number)}
      ${field('Label', `about.stats.${i}.label`, item.label)}
    </div>`).join('');
}

/* ---------------- Global events ---------------- */
function wireGlobalActions(){
  const content = document.getElementById('admin-content');

  content.addEventListener('input', e => {
    const path = e.target.dataset.path;
    if(!path) return;
    setPath(state, path, e.target.value);
    saveDraft();
  });

  content.addEventListener('click', e => {
    const btn = e.target.closest('button[data-action]');
    if(!btn) return;
    const action = btn.dataset.action;

    if(action.startsWith('add-')){
      const key = action.replace('add-', '');
      const blank = key === 'services' ? { icon:'✨', title:'' }
        : key === 'destinations' ? { name:'', image:'' }
        : { name:'', role:'', text:'' };
      state[key] = state[key] || [];
      state[key].push(blank);
      saveDraft();
      renderRepeatable(key,
        key === 'services' ? ['icon','title'] : key === 'destinations' ? ['name','image'] : ['name','role','text'],
        key === 'services' ? ['Icon (emoji)','Title'] : key === 'destinations' ? ['Name','Image URL (optional)'] : ['Name','Role / trip','Quote'],
        key === 'testimonials' ? ['input','input','textarea'] : null
      );
    }

    if(action.startsWith('remove-')){
      const key = action.replace('remove-', '');
      const index = parseInt(btn.dataset.index, 10);
      state[key].splice(index, 1);
      saveDraft();
      renderRepeatable(key,
        key === 'services' ? ['icon','title'] : key === 'destinations' ? ['name','image'] : ['name','role','text'],
        key === 'services' ? ['Icon (emoji)','Title'] : key === 'destinations' ? ['Name','Image URL (optional)'] : ['Name','Role / trip','Quote'],
        key === 'testimonials' ? ['input','input','textarea'] : null
      );
    }
  });

  document.getElementById('btn-download').addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'data.json';
    a.click();
    URL.revokeObjectURL(url);
  });

  document.getElementById('btn-copy').addEventListener('click', async () => {
    await navigator.clipboard.writeText(JSON.stringify(state, null, 2));
    const btn = document.getElementById('btn-copy');
    const old = btn.textContent;
    btn.textContent = 'Copied ✓';
    setTimeout(() => btn.textContent = old, 1500);
  });

  document.getElementById('btn-preview').addEventListener('click', () => {
    window.open('index.html', '_blank');
  });
}

init();
