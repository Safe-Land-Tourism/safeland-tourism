// Safe Land Tourism LLC — renders the site from data.json
// Edit content via admin.html, then replace data.json in your GitHub repo.

async function loadContent(){
  const res = await fetch('data.json?_=' + Date.now());
  if(!res.ok) throw new Error('data.json not found');
  return res.json();
}

function el(html){
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}

function renderSite(d){
  document.title = d.site.title + ' — ' + d.site.tagline;

  // Header
  document.getElementById('logo-text').innerHTML =
    `<span class="hi">${d.site.logo_text.split(' ')[0] || ''}</span> <span class="lo">${d.site.logo_text.split(' ').slice(1).join(' ')}</span>`;
  document.getElementById('header-cta').textContent = d.hero.cta_text;
  document.getElementById('header-cta').href = d.hero.cta_link;

  // Hero
  document.getElementById('hero-eyebrow').textContent = '📍 ' + d.hero.eyebrow;
  document.getElementById('hero-title').textContent = d.hero.name;
  document.getElementById('hero-role').textContent = d.hero.role;
  document.getElementById('hero-intro').textContent = d.hero.intro;
  const ctaPrimary = document.getElementById('hero-cta-primary');
  ctaPrimary.textContent = d.hero.cta_text; ctaPrimary.href = d.hero.cta_link;
  const ctaSecondary = document.getElementById('hero-cta-secondary');
  ctaSecondary.textContent = d.hero.secondary_cta_text; ctaSecondary.href = d.hero.secondary_cta_link;

  // About
  document.getElementById('about-heading').textContent = d.about.heading;
  document.getElementById('about-text').textContent = d.about.text;
  document.getElementById('md-name').textContent = d.about.md_name;
  document.getElementById('md-title').textContent = d.about.md_title;
  document.getElementById('md-avatar').textContent = (d.about.md_name || '?').trim().charAt(0);
  const statsRow = document.getElementById('stats-row');
  statsRow.innerHTML = '';
  (d.about.stats || []).forEach(s => {
    statsRow.appendChild(el(`<div class="stat"><b>${s.number}</b><span>${s.label}</span></div>`));
  });

  // Services
  const servicesGrid = document.getElementById('services-grid');
  servicesGrid.innerHTML = '';
  (d.services || []).forEach(s => {
    servicesGrid.appendChild(el(`
      <div class="service-row">
        <div class="icon">${s.icon || '•'}</div>
        <div class="title">${s.title}</div>
      </div>`));
  });

  // Destinations
  const destRow = document.getElementById('dest-row');
  destRow.innerHTML = '';
  (d.destinations || []).forEach(dst => {
    const bg = dst.image ? `style="background-image:url('${dst.image}')"` : '';
    destRow.appendChild(el(`
      <div class="dest-item">
        <div class="dest-photo" ${bg}>${dst.image ? '' : '🕌'}</div>
        <div class="name">${dst.name}</div>
      </div>`));
  });

  // Testimonials
  const testiGrid = document.getElementById('testi-grid');
  testiGrid.innerHTML = '';
  (d.testimonials || []).forEach(t => {
    testiGrid.appendChild(el(`
      <div class="testi-card">
        <div class="quote">“${t.text}”</div>
        <div class="who"><b>${t.name}</b><span>${t.role}</span></div>
      </div>`));
  });

  // Contact
  document.getElementById('contact-heading').textContent = d.contact.heading;
  document.getElementById('contact-subtext').textContent = d.contact.subtext;
  document.getElementById('contact-address').textContent = d.contact.address;
  document.getElementById('contact-phone').textContent = d.contact.phone;
  document.getElementById('contact-phone').href = 'tel:' + d.contact.phone.replace(/\s+/g,'');
  document.getElementById('contact-email').textContent = d.contact.email;
  document.getElementById('contact-email').href = 'mailto:' + d.contact.email;
  document.getElementById('contact-website').textContent = d.contact.website;
  document.getElementById('contact-website').href = 'https://' + d.contact.website.replace(/^https?:\/\//,'');

  const socialIcons = { instagram:'📷', facebook:'📘', youtube:'▶️', linkedin:'in', twitter:'🐦', tiktok:'🎵' };
  const socialRow = document.getElementById('social-row');
  socialRow.innerHTML = '';
  Object.entries(d.contact.socials || {}).forEach(([k,url]) => {
    if(!url) return;
    socialRow.appendChild(el(`<a href="${url}" target="_blank" rel="noopener" aria-label="${k}">${socialIcons[k] || '🔗'}</a>`));
  });

  // Footer
  document.getElementById('footer-text').textContent = d.footer.text;
}

document.addEventListener('DOMContentLoaded', () => {
  loadContent().then(renderSite).catch(err => {
    console.error(err);
    document.body.innerHTML = '<p style="padding:40px;font-family:sans-serif">Could not load data.json. Make sure it is in the same folder as index.html and that you are viewing this through a web server (e.g. GitHub Pages), not a local double-clicked file.</p>';
  });

  const toggle = document.getElementById('nav-toggle');
  const nav = document.getElementById('main-nav');
  if(toggle){
    toggle.addEventListener('click', () => nav.classList.toggle('open'));
    nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));
  }
});
